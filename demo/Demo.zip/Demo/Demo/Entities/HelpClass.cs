﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Entities
{
    class HelpClass
    {
        public string Article { get; set; }
        public string Name { get; set; }
        public string Manufacturer { get; set; }
        public int Count { get; set; }
        public decimal Cost { get; set; }
    }
}
