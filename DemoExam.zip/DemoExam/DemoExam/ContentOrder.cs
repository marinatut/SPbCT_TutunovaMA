﻿using System;
using System.Collections.Generic;

namespace DemoExam
{
    public partial class ContentOrder
    {
        public int ContentId { get; set; }
        public int OrderId { get; set; }
        public string ProductArticleNumber { get; set; }
        public int ProductAmount { get; set; }

        public virtual Order Order { get; set; }
        public virtual Product ProductArticleNumberNavigation { get; set; }
    }
}
