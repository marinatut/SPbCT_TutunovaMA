﻿using System;
using System.Collections.Generic;

namespace DemoExam
{
    public partial class Provider
    {
        public Provider()
        {
            Product = new HashSet<Product>();
        }

        public int ProviderId { get; set; }
        public string Provider1 { get; set; }

        public virtual ICollection<Product> Product { get; set; }
    }
}
