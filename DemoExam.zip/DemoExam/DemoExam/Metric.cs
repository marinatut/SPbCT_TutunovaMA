﻿using System;
using System.Collections.Generic;

namespace DemoExam
{
    public partial class Metric
    {
        public Metric()
        {
            Product = new HashSet<Product>();
        }

        public int MetricId { get; set; }
        public string MetricName { get; set; }

        public virtual ICollection<Product> Product { get; set; }
    }
}
