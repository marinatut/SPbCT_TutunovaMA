﻿using System;
using System.Collections.Generic;

namespace DemoExam
{
    public partial class Order
    {
        public Order()
        {
            ContentOrder = new HashSet<ContentOrder>();
        }

        public int OrderId { get; set; }
        public int OrderClient { get; set; }
        public int OrderStatus { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime OrderDeliveryDate { get; set; }
        public int OrderCode { get; set; }
        public int OrderPickupPoint { get; set; }

        public virtual User OrderClientNavigation { get; set; }
        public virtual PickupPoint OrderPickupPointNavigation { get; set; }
        public virtual StatusOrder OrderStatusNavigation { get; set; }
        public virtual ICollection<ContentOrder> ContentOrder { get; set; }
    }
}
