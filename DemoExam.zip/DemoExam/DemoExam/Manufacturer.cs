﻿using System;
using System.Collections.Generic;

namespace DemoExam
{
    public partial class Manufacturer
    {
        public Manufacturer()
        {
            Product = new HashSet<Product>();
        }

        public int ManufacturerId { get; set; }
        public string Manufacturer1 { get; set; }

        public virtual ICollection<Product> Product { get; set; }
    }
}
