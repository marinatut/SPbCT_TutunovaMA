﻿using System;
using System.Collections.Generic;

namespace DemoExam
{
    public partial class PickupPoint
    {
        public PickupPoint()
        {
            Order = new HashSet<Order>();
        }

        public int PickupPointId { get; set; }
        public decimal PickupPointNumber { get; set; }
        public string PickupAdres { get; set; }

        public virtual ICollection<Order> Order { get; set; }
    }
}
