﻿using System;
using System.Collections.Generic;

namespace DemoExam
{
    public partial class Product
    {
        public Product()
        {
            ContentOrder = new HashSet<ContentOrder>();
        }

        public string ProductArticleNumber { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public int ProductCategory { get; set; }
        public byte[] ProductPhoto { get; set; }
        public int ProductManufacturer { get; set; }
        public decimal ProductCost { get; set; }
        public decimal? ProductDiscountAmount { get; set; }
        public int ProductQuantityInStock { get; set; }
        public int ProductStatus { get; set; }
        public int ProductMetric { get; set; }
        public int ProductProvider { get; set; }
        public decimal ProductMaxDiscount { get; set; }

        public virtual Category ProductCategoryNavigation { get; set; }
        public virtual Manufacturer ProductManufacturerNavigation { get; set; }
        public virtual Metric ProductMetricNavigation { get; set; }
        public virtual Provider ProductProviderNavigation { get; set; }
        public virtual StatusProduct ProductStatusNavigation { get; set; }
        public virtual ICollection<ContentOrder> ContentOrder { get; set; }
    }
}
