﻿using System;
using System.Collections.Generic;

namespace DemoExam
{
    public partial class StatusOrder
    {
        public StatusOrder()
        {
            Order = new HashSet<Order>();
        }

        public int StatusId { get; set; }
        public string Status { get; set; }

        public virtual ICollection<Order> Order { get; set; }
    }
}
