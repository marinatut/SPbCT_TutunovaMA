﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace DemoExam.Page
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth
    {
        private byte _failedCounter = 0;
        private DispatcherTimer _timer = new DispatcherTimer();
        private string _answerCaptcha = null;
        public Auth()
        {
            InitializeComponent();
            UpdateCaptcha();
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            tbxLogin.Text = "";
            tbxPassword.Password = "";
            tbxCaptcha.Text = "";
        }

        private async void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tbxLogin.Text == "" || tbxPassword.Password == "")
                {
                    MessageBox.Show("Ошибка: пустые поля");
                    return;
                }
                var currentUser = await App.DB.User.FirstOrDefaultAsync(n => n.UserLogin == tbxLogin.Text && n.UserPassword == tbxPassword.Password);
                if (currentUser != null && _failedCounter == 0)
                {
                    App.CurrentUser = currentUser;
                    NavigationService.Navigate(new Page.Product());
                }
                if (currentUser != null && _answerCaptcha.ToLower() == tbxCaptcha.Text.ToLower())
                {
                    App.CurrentUser = currentUser;
                    NavigationService.Navigate(new Page.Product());
                }
                if (_failedCounter == 2)
                {
                    MessageBox.Show("Вы ввели данные неправильно более 2-ух раз,\nкнопка заблокирована на 10 секунд", "Блокировка кнопки",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    UpdateCaptcha();
                    _failedCounter = 0;
                    btnEnter.IsEnabled = false;
                    _timer.Interval = TimeSpan.FromSeconds(10);
                    _timer.Tick += TimerTick;
                    _timer.Start();
                }
                else if (_answerCaptcha.ToLower() != tbxCaptcha.Text.ToLower() && _failedCounter > 0)
                {
                    MessageBox.Show("Проверьте ввод каптчи", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
                    UpdateCaptcha();
                    _failedCounter++;
                }
                else if (currentUser == null)
                {
                    MessageBox.Show("Логин или пароль введены неправильно", "Ошибка авторизации",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    UpdateCaptcha();
                    tbxCaptcha.Visibility = Visibility.Visible;
                    MyCaptcha.Visibility = Visibility.Visible;
                    _failedCounter++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка при авторизации");
            }
        }

        private void UpdateCaptcha() // Метод обновления каптчи
        {
            MyCaptcha.CreateCaptcha(EasyCaptcha.Wpf.Captcha.LetterOption.Alphanumeric, 4);
            _answerCaptcha = MyCaptcha.CaptchaText;
        }
        private void TimerTick(object sender, EventArgs e) // Метод, который будет вызван по окончанию таймера
        {
            _timer.Stop();
            btnEnter.IsEnabled = true;
            tbxLogin.Text = "";
            tbxCaptcha.Text = "";
            tbxPassword.Password = "";
        }
    }
}
