﻿using System;
using System.Collections.Generic;

namespace DemoExam
{
    public partial class StatusProduct
    {
        public StatusProduct()
        {
            Product = new HashSet<Product>();
        }

        public int StatusId { get; set; }
        public string Status { get; set; }

        public virtual ICollection<Product> Product { get; set; }
    }
}
